import type { Metadata } from "next";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import FloatingActions from "@/components/FloatingActions";
import CategoryHero from "@/components/category/CategoryHero";
import CategoryCraft from "@/components/category/CategoryCraft";
import CategoryCTA from "@/components/category/CategoryCTA";
import SummaryStrip from "@/components/category/SummaryStrip";
import InfoPanelSection from "@/components/category/InfoPanelSection";
import InfoPanel from "@/components/category/InfoPanel";
import { ShieldCheckIcon, TrendUpIcon, GemClusterIcon, GlobeIcon } from "@/components/category/icons";
import { LOCALE } from "@/lib/i18n";
import { localized } from "@/lib/content";
import {
  GOLD_TEXT,
  SECTION_1_POINTS,
  SECTION_2_POINTS,
  SECTION_3_POINTS,
  SECTION_4_POINTS,
  SUMMARY_POINTS,
} from "@/lib/investmentGold";

export const metadata: Metadata = {
  title: "Investment Gold — LIDYA JEWELRY",
  description:
    "999.9 fine gold bars and sovereign coins from 1 gram to a full kilo — certified, sealed and ready to be held as a private, portable store of value.",
};

// One icon per summary takeaway, matched 1:1 to SUMMARY_POINTS.
const SUMMARY_ICONS = [ShieldCheckIcon, TrendUpIcon, GemClusterIcon, ShieldCheckIcon, GlobeIcon];

export default function InvestmentGoldPage() {
  const t = (key: keyof typeof GOLD_TEXT) => localized(GOLD_TEXT[key], LOCALE);

  return (
    <>
      <Header />
      <main>
        <CategoryHero
          eyebrow={t("heroEyebrow")}
          title={t("heroTitle")}
          lead={t("heroLead")}
          icon={<TrendUpIcon />}
          image="/images/investment-gold/hero.jpg"
          imageAlt="A row of gold bars of increasing size on silk fabric"
        />

        <InfoPanelSection eyebrow={t("section1Eyebrow")} title={t("section1Title")}>
          {SECTION_1_POINTS.map((p, i) => (
            <InfoPanel
              key={i}
              number={String(i + 1).padStart(2, "0")}
              title={localized(p.title, LOCALE)}
              description={localized(p.description, LOCALE)}
              image={p.image}
              imageWidth={p.imageWidth}
              imageHeight={p.imageHeight}
              imageAlt={p.imageAlt}
            />
          ))}
        </InfoPanelSection>

        <InfoPanelSection eyebrow={t("section2Eyebrow")} title={t("section2Title")}>
          {SECTION_2_POINTS.map((p, i) => (
            <InfoPanel
              key={i}
              number={String(i + 1).padStart(2, "0")}
              title={localized(p.title, LOCALE)}
              description={localized(p.description, LOCALE)}
              image={p.image}
              imageWidth={p.imageWidth}
              imageHeight={p.imageHeight}
              imageAlt={p.imageAlt}
            />
          ))}
        </InfoPanelSection>

        <InfoPanelSection eyebrow={t("section3Eyebrow")} title={t("section3Title")}>
          {SECTION_3_POINTS.map((p, i) => (
            <InfoPanel
              key={i}
              number={String(i + 1).padStart(2, "0")}
              title={localized(p.title, LOCALE)}
              description={localized(p.description, LOCALE)}
              image={p.image}
              imageWidth={p.imageWidth}
              imageHeight={p.imageHeight}
              imageAlt={p.imageAlt}
            />
          ))}
        </InfoPanelSection>

        <CategoryCraft
          eyebrow={t("section4Eyebrow")}
          title={t("section4Title")}
          points={SECTION_4_POINTS.map((p) => ({
            title: localized(p.title, LOCALE),
            description: localized(p.description, LOCALE),
          }))}
        />

        <SummaryStrip
          items={SUMMARY_POINTS.map((text, i) => {
            const Icon = SUMMARY_ICONS[i % SUMMARY_ICONS.length];
            return { icon: <Icon />, text: localized(text, LOCALE) };
          })}
        />

        <CategoryCTA title={t("ctaTitle")} sub={t("ctaSub")} />
      </main>
      <Footer />
      <FloatingActions />
    </>
  );
}
